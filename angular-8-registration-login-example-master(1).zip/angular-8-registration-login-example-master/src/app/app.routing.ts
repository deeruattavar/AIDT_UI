﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { FormerComponent } from './former';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';
import { AuthGuard } from './_helpers';
import { AgentComponent } from './agent';
import { Scanner } from './scanner';
import { BarcodeScannerLivestreamRouteComponent } from './+barcode-scanner-livestream/barcode-scanner-livestream-route.component';

const routes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'former', component: FormerComponent },
    { path: 'agent', component: AgentComponent },
    { path: 'scanner', component:Scanner},
    { path: 'scanner1', component:BarcodeScannerLivestreamRouteComponent},

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);