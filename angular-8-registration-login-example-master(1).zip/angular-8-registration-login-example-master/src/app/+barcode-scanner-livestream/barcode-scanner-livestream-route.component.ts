import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { BarecodeScannerLivestreamComponent } from 'ngx-barcode-scanner';

@Component({
    selector: 'app-barcode-scanner-livestream',
    templateUrl: './barcode-scanner-livestream-route.component.html'
})
export class BarcodeScannerLivestreamRouteComponent implements AfterViewInit {

    @ViewChild(BarecodeScannerLivestreamComponent,  {read:'asd', static:true})
    barecodeScanner: BarecodeScannerLivestreamComponent;

    barcodeValue;

    ngAfterViewInit() {
        this.barecodeScanner.start();
    }

    onValueChanges(result) {
        this.barcodeValue = result.codeResult.code;
    }

}
